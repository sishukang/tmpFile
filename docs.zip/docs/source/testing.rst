torch.testing
=============

.. automodule:: torch.testing
.. currentmodule:: torch.testing

.. autofunction:: assert_close
.. autofunction:: make_tensor
