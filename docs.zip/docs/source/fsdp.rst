FullyShardedDataParallel
========================

.. automodule:: torch.distributed.fsdp

.. autoclass:: torch.distributed.fsdp.FullyShardedDataParallel
  :members:
