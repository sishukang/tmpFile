torch.utils.cpp_extension
=========================

.. currentmodule:: torch.utils.cpp_extension
.. autofunction:: CppExtension
.. autofunction:: CUDAExtension
.. autofunction:: BuildExtension
.. autofunction:: load
.. autofunction:: load_inline
.. autofunction:: include_paths
.. autofunction:: get_compiler_abi_compatibility_and_version
.. autofunction:: verify_ninja_availability
.. autofunction:: is_ninja_available
