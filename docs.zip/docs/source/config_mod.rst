torch.__config__
===================================

.. automodule:: torch.__config__
.. currentmodule:: torch.__config__

.. autofunction:: show
.. autofunction:: parallel_info
