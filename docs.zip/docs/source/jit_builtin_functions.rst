.. _builtin-functions:

TorchScript Builtins
====================

This is a full reference of functions and Tensor methods accessible in TorchScript

.. contents:: :local:

.. automodule:: torch.jit.supported_ops
