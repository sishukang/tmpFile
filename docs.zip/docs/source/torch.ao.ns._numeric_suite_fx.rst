.. _torch_ao_ns_numeric_suite_fx:

torch.ao.ns._numeric_suite_fx
-----------------------------

.. warning ::
     This module is an early prototype and is subject to change.

.. currentmodule:: torch.ao.ns._numeric_suite_fx

.. automodule:: torch.ao.ns._numeric_suite_fx
    :members:
    :member-order: bysource


torch.ao.ns.fx.utils
--------------------------------------

.. warning ::
     This module is an early prototype and is subject to change.

.. currentmodule:: torch.ao.ns.fx.utils

.. autofunction:: torch.ao.ns.fx.utils.compute_sqnr(x, y)
.. autofunction:: torch.ao.ns.fx.utils.compute_normalized_l2_error(x, y)
.. autofunction:: torch.ao.ns.fx.utils.compute_cosine_similarity(x, y)
