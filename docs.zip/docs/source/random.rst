torch.random
===================================

.. currentmodule:: torch.random

.. automodule:: torch.random
   :members:
