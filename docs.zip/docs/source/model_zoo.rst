torch.utils.model_zoo
===================================

Moved to `torch.hub`.

.. automodule:: torch.utils.model_zoo
.. autofunction:: load_url
