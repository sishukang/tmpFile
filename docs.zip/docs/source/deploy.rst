torch::deploy has been moved to pytorch/multipy
===============================================

``torch::deploy`` has been moved to its new home at `https://github.com/pytorch/multipy <https://github.com/pytorch/multipy>`_.
