.. _launcher-api:

torchrun (Elastic Launch)
======================================

.. automodule:: torch.distributed.run
