.. _elastic_errors-api:

Error Propagation
==================

.. automodule:: torch.distributed.elastic.multiprocessing.errors

Methods and Classes
---------------------

.. currentmodule:: torch.distributed.elastic.multiprocessing.errors

.. autofunction:: torch.distributed.elastic.multiprocessing.errors.record

.. autoclass:: ChildFailedError

.. autoclass:: ErrorHandler

.. autoclass:: ProcessFailure
