TorchElastic Kubernetes
==========================

Please refer to our github's `Kubernetes README <https://github.com/pytorch/elastic/tree/master/kubernetes>`_
for more information on Elastic Job Controller and custom resource definition.
