torch.utils.dlpack
==================

.. currentmodule:: torch.utils.dlpack

.. autofunction:: from_dlpack
.. autofunction:: to_dlpack
