# lintrunner adapters

These files adapt our various linters to work with `lintrunner`.

## Adding a new linter
1. init and linter
2. {{DRYRUN}} and {{PATHSFILE}}
3. never exit uncleanly
4. Communication protocol
5. Self-contained
