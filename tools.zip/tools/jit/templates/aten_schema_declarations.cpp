namespace torch { namespace jit {
const char * schema_declarations = R"===(
  ${declarations}
)===";
}}
