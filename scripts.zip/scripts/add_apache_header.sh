cat  apache_header.txt $1 > _add_apache_header.txt && mv _add_apache_header.txt $1
