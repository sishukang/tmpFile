from typing import NamedTuple

import torch

class MyNamedTup(NamedTuple):
    i : torch.Tensor
    f : torch.Tensor
