from .cells import *  # noqa: F403
from .factory import *  # noqa: F403

# (output, next_state) = cell(input, state)
seqLength = 100
numLayers = 2
inputSize = 512
hiddenSize = 512
miniBatch = 64
