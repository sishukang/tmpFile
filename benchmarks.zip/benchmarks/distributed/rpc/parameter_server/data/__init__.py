from .DummyData import DummyData

data_map = {
    "DummyData": DummyData
}
