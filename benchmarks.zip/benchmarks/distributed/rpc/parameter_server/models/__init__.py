from .DummyModel import DummyModel

model_map = {
    "DummyModel": DummyModel
}
