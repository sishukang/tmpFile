#Sparse benchmarks

These sets of benchmarks are for the sparse matrix functionality. They exist for
comparing the performance of sparse matrix routines such as SpMV between various
sparse matrix formats and with other frameworks such as TensorFlow.
