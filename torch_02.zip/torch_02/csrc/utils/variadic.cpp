#define TORCH_ASSERT_ONLY_METHOD_OPERATORS
#include <torch/csrc/utils/variadic.h>
