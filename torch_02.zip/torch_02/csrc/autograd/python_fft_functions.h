#pragma once

namespace torch {
namespace autograd {

void initFFTFunctions(PyObject* module);

}
} // namespace torch
