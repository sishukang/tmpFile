#pragma once

namespace torch {
namespace autograd {

void initNestedFunctions(PyObject* module);

}
} // namespace torch
