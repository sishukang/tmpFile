# torch::deploy has been moved to pytorch/multipy
Please check out [https://github.com/pytorch/multipy](https://github.com/pytorch/multipy) to find the new home for torch::deploy.
