#ifndef LibTorch_Lite_h
#define LibTorch_Lite_h

#include <torch/csrc/jit/mobile/import.h>
#include <torch/csrc/jit/mobile/module.h>
#include <torch/script.h>

#endif
