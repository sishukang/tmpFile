#ifndef LibTorch_h
#define LibTorch_h

#include <torch/script.h>

#endif
