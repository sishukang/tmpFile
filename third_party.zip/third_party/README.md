This folder contains vendored copies of third-party libraries that we
use.
