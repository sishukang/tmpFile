#include <c10/core/StreamGuard.h>

// At the moment, just make sure it compiles
