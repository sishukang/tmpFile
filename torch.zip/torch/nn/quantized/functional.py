r"""nn.quantized.functional

Quantized equivalents of the `nn.functional`.

Note::
    This location is in the process of being deprecated.
    Please, use the `torch.ao.nn.quantized.functional` instead.
"""

from torch.ao.nn.quantized.functional import *  # noqa: F401,F403
