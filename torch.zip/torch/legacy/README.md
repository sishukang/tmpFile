If you're looking for this legacy code please consider versions of PyTorch before 0.5
