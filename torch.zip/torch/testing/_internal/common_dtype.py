# flake8: noqa F401

"""The implementations should be moved here as soon as their deprecation period is over."""
from torch.testing._legacy import (
    _validate_dtypes,
    _dispatch_dtypes,
    all_types,
    all_types_and,
    all_types_and_complex,
    all_types_and_complex_and,
    all_types_and_half,
    complex_types,
    complex_types_and,
    empty_types,
    floating_and_complex_types,
    floating_and_complex_types_and,
    floating_types,
    floating_types_and,
    double_types,
    floating_types_and_half,
    get_all_complex_dtypes,
    get_all_dtypes,
    get_all_fp_dtypes,
    get_all_int_dtypes,
    get_all_math_dtypes,
    integral_types,
    integral_types_and,
)
