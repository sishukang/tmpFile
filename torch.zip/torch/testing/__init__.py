from ._comparison import assert_close
from torch._C import FileCheck
from ._creation import make_tensor
from ._deprecated import *  # noqa: F403
