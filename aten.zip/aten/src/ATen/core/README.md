ATen Core
---------

ATen Core is a minimal subset of ATen which is suitable for deployment
on mobile.  Binary size of files in this folder is an important constraint.
