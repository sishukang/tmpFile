//aiss add for hipify tool
#pragma once

#if defined(USE_ROCM)
#define __DTK_ARCH__ 520
#define DTK_VERSION 11800
#endif
