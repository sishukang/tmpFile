MOBILE_UPGRADERS_HEADER_DESCRIPTION = """/**
 * @generated
 * This is an auto-generated file. Please do not modify it by hand.
 * To re-generate, please run:
 * cd ~/pytorch && python torchgen/operator_versions/gen_mobile_upgraders.py
 */
"""
