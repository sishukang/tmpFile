#include "caffe2/core/tensor_int8.h"
#include <c10/util/typeid.h>

namespace caffe2 {
CAFFE_KNOWN_TYPE(int8::Int8TensorCPU);
} // namespace caffe2
