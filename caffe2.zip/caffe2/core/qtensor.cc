#include "caffe2/core/qtensor.h"

namespace caffe2 {
CAFFE_KNOWN_TYPE(QTensor<CPUContext>);
}
