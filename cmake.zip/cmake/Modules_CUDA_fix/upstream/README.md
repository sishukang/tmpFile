If you need to update files under this folder, we recommend you issue PRs
against [the CMake mainline branch](https://gitlab.kitware.com/cmake/cmake/tree/master/Modules/FindCUDA.cmake),
and then backport it here for earlier CMake compatibility.

See [this](../README.md) for more details.
